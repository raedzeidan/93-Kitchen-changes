import { useEffect } from 'react'

/** Main website: reuses the standalone 93 Kitchen UI and all its RTL routes. */
export default function App() {
  useEffect(() => {
    import('./site/app').catch((error) => console.error('93 Kitchen initialization failed:', error))
  }, [])
  return <div id="app" />
}
