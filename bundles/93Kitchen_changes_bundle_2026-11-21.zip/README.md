# 93 Kitchen — RTL website & staff dashboard

Source design: https://www.figma.com/design/1lyrLGHubD9KHHevKfPW4g/93Kitchen-new?node-id=0-1

A responsive, no-build static HTML/CSS/JavaScript implementation of the current 93 Kitchen design system: Cairo font, forest green `#0E5A41`, accent orange `#F28C28`, center-aligned hero, meal cards, subscription planner and restaurant management dashboard.

## Run locally

Serve this directory with a static HTTP server, for example `python -m http.server 8080`, then open the indicated local URL. There are no frontend package dependencies. `index.html` is the entry point. The same directory can be imported to Figma Make.

## Implemented routes

Customer: `#/home`, `#/menu`, `#/plans`, `#/planner`, `#/cart`, `#/identity`, `#/login`, `#/signup`, `#/details`, `#/review`, `#/payment`, `#/pending`, `#/account`, `#/orders`, `#/about`, `#/terms`.

Staff: `#/staff-login`, `#/dashboard`, with sidebar sections for orders, subscriptions, menus, customers, complaints, finances and permissions.

The customer menu, allergy filtering, cart, subscription choice, location picker, 4-week planner (20 meals), identity/guest entry, customer profile and order tracking are interactive. Staff dashboards have clickable navigation, search, filters, forms and browser-local edits.

## Integration required before production

**The app is a frontend scaffold, not a deployed live ordering or payment system.** It currently uses browser `localStorage`; it does not authenticate, charge money, or confirm delivery zones in a production database.

- Replace `MEALS`, `PLANS`, `ZONES`, `GOVERNORATES`, and `DEFAULT_TABLES` in `app.js` with real database/API responses and verified restaurant business rules.
- Replace sample content and photo placeholders with approved actual menu photos, ingredients, allergen data, customer reviews and prices. Only the user-supplied brand assets and photos are present in `assets/`.
- Add authenticated customer and employee accounts using an identity provider, strong server-side session handling and role-based access control. Current frontend employee login is not authentication and must not protect production finance or permissions pages.
- Link CliQ to a verified merchant account and payment reconciliation workflow; **never assume a transfer succeeded from a frontend button**. Restaurant QR is a static reference sample and must become a per-order server-generated QR referencing the real order ID.
- Integrate actual governorate/zone coverage tables and delivery fees before accepting payments. Showing a zone in the dropdown does not promise delivery.
- Add backend persistence for orders, subscriptions, service/meal cutoff times, delivery scheduling, messages, complaints and auditing.
- Validate account details, delivery inputs, and order totals server-side, with rate limiting and permissions.
- Set restaurant contact destinations (WhatsApp, Facebook, telephone) to confirmed official accounts before launch.

## Assets

`assets/logo.svg` is the supplied brand SVG; `assets/hero.png` is the supplied transparent hero; `assets/chef.webp`, `assets/meal-chicken.webp`, and `assets/meal-balanced.webp` are resized copies of user-supplied imagery. Remaining unverified meal photos are represented by graphic placeholders rather than fabricated dish photos. `assets/reference-qr.png` represents the current example reference, pending order-level QR generation.

## QA

The code is syntax-checked using `node --check app.js` and a script-level DOM mock, plus archive integrity checks. A real browser-based visual run is needed on the Figma Make side because the local automation environment blocks browser navigation to local file and localhost URLs.
